// Fashion Affiliate Website - Main JavaScript
// Handles all interactive functionality, animations, and user interactions

// Global variables
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
let products = [];
let filteredProducts = [];
let currentPage = 1;
const productsPerPage = 12;

// Product data with realistic fashion items
const productData = [
    {
        id: 1,
        name: "Classic Polo Shirt",
        brand: "Lacoste",
        category: "tops",
        price: 89,
        salePrice: 62,
        discount: 30,
        rating: 4.5,
        reviews: 89,
        image: "https://kimi-web-img.moonshot.cn/img/ae01.alicdn.com/81c5c0e6266298f23a133dbcc2bcf2b4027b83c9.jpg",
        description: "Classic cotton polo shirt with iconic crocodile logo. Perfect for casual and semi-formal occasions.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["White", "Navy", "Black", "Red"]
    },
    {
        id: 2,
        name: "Tailored Blazer",
        brand: "Zara",
        category: "outerwear",
        price: 129,
        salePrice: 97,
        discount: 25,
        rating: 4.8,
        reviews: 156,
        image: "https://kimi-web-img.moonshot.cn/img/www.stormonline.com/2a969389df5491f9de5565e637f66e482e2b4f24.jpg",
        description: "Structured blazer with modern fit. Ideal for professional and smart casual looks.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["Black", "Navy", "Gray", "Beige"]
    },
    {
        id: 3,
        name: "Stan Smith Sneakers",
        brand: "Adidas",
        category: "shoes",
        price: 85,
        salePrice: 68,
        discount: 20,
        rating: 4.3,
        reviews: 203,
        image: "https://kimi-web-img.moonshot.cn/img/cdn.thewirecutter.com/1725db6be16aa2f3b4481d0ba06bfd7a8cd870b2.jpg",
        description: "Iconic white leather sneakers with green accents. Timeless design for everyday wear.",
        sizes: ["6", "7", "8", "9", "10", "11"],
        colors: ["White/Green", "White/Navy", "All White"]
    },
    {
        id: 4,
        name: "Silk Midi Dress",
        brand: "Reformation",
        category: "dresses",
        price: 248,
        salePrice: 161,
        discount: 35,
        rating: 4.9,
        reviews: 78,
        image: "https://kimi-web-img.moonshot.cn/img/fleurdumal.com/3edd4188f7a6967bc6be65a4a002974d15c4f33d.jpg",
        description: "Elegant silk dress with flowing silhouette. Perfect for special occasions and evening events.",
        sizes: ["XS", "S", "M", "L"],
        colors: ["Champagne", "Rose", "Emerald", "Black"]
    },
    {
        id: 5,
        name: "Cashmere Sweater",
        brand: "Everlane",
        category: "tops",
        price: 168,
        salePrice: 118,
        discount: 30,
        rating: 4.7,
        reviews: 124,
        image: "https://kimi-web-img.moonshot.cn/img/img.gocashmere.com/116f735f1097f326a213f05c389971a4352c7835.jpg",
        description: "Luxurious cashmere sweater with relaxed fit. Soft, warm, and sustainably sourced.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["Cream", "Gray", "Navy", "Camel"]
    },
    {
        id: 6,
        name: "Gray Denim Jeans",
        brand: "Levi's",
        category: "bottoms",
        price: 98,
        salePrice: 73,
        discount: 25,
        rating: 4.4,
        reviews: 189,
        image: "https://kimi-web-img.moonshot.cn/img/image.uniqlo.com/97d341d560dd610ef0d03be2caa043ecf42f1f75.jpg",
        description: "Classic straight-leg jeans in gray wash. Versatile styling for casual and smart casual looks.",
        sizes: ["24", "26", "28", "30", "32", "34"],
        colors: ["Light Gray", "Dark Gray", "Black"]
    },
    {
        id: 7,
        name: "Designer Handbag",
        brand: "Coach",
        category: "accessories",
        price: 395,
        salePrice: 276,
        discount: 30,
        rating: 4.6,
        reviews: 92,
        image: "https://kimi-web-img.moonshot.cn/img/www.christies.com/a6dd47f0aa2dc75c172d0e8694d4273405147721.jpg",
        description: "Premium leather handbag with gold hardware. Spacious interior with multiple compartments.",
        sizes: ["One Size"],
        colors: ["Black", "Brown", "Tan", "Burgundy"]
    },
    {
        id: 8,
        name: "Tennis Skirt",
        brand: "Nike",
        category: "bottoms",
        price: 65,
        salePrice: 52,
        discount: 20,
        rating: 4.2,
        reviews: 167,
        image: "https://kimi-web-img.moonshot.cn/img/ae01.alicdn.com/552316e011fafbec230177467acd1495d188e9af.jpg",
        description: "Performance tennis skirt with built-in shorts. Moisture-wicking fabric for active wear.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["White", "Navy", "Black", "Pink"]
    },
    {
        id: 9,
        name: "Luxury Streetwear Hoodie",
        brand: "Fear of God",
        category: "tops",
        price: 295,
        salePrice: 206,
        discount: 30,
        rating: 4.8,
        reviews: 67,
        image: "https://kimi-web-img.moonshot.cn/img/www.urkoolwear.com/6e36768995945ddf6d44ff116df94ea7610093c3.jpg",
        description: "Premium cotton blend hoodie with oversized fit. Elevated streetwear aesthetic.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["Cream", "Gray", "Black", "Olive"]
    },
    {
        id: 10,
        name: "Patent Leather Loafers",
        brand: "Gucci",
        category: "shoes",
        price: 850,
        salePrice: 595,
        discount: 30,
        rating: 4.9,
        reviews: 45,
        image: "https://kimi-web-img.moonshot.cn/img/www.mandysheaven.com/5b8c44dd456297fee256cc75c0bfcdc782b12314.jpg",
        description: "Luxury patent leather loafers with horsebit detail. Iconic Italian craftsmanship.",
        sizes: ["6", "7", "8", "9", "10", "11"],
        colors: ["Black", "Burgundy", "Navy"]
    },
    {
        id: 11,
        name: "Wide-Leg Trousers",
        brand: "COS",
        category: "bottoms",
        price: 115,
        salePrice: 86,
        discount: 25,
        rating: 4.3,
        reviews: 134,
        image: "https://kimi-web-img.moonshot.cn/img/cdn.optipic.io/e65d1d523a263f5d1b486c43fb4366b33717f425.jpg",
        description: "Modern wide-leg trousers with pressed creases. Perfect for office and smart casual wear.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["Black", "Navy", "Gray", "Beige"]
    },
    {
        id: 12,
        name: "Leopard Print Coat",
        brand: "Saint Laurent",
        category: "outerwear",
        price: 2890,
        salePrice: 2023,
        discount: 30,
        rating: 4.7,
        reviews: 23,
        image: "https://kimi-web-img.moonshot.cn/img/www.aliceandolivia.com/76dc2cfb5b35fa82a72a3ab732c5ea104ccfdca1.jpg",
        description: "Statement leopard print coat with luxurious wool blend. Bold fashion piece for confident style.",
        sizes: ["XS", "S", "M", "L"],
        colors: ["Leopard Print", "Black", "Brown"]
    },
    {
        id: 13,
        name: "Off-White Sweater",
        brand: "Everlane",
        category: "tops",
        price: 88,
        salePrice: 66,
        discount: 25,
        rating: 4.5,
        reviews: 198,
        image: "https://kimi-web-img.moonshot.cn/img/cdn.clothbase.com/964057a714962416eea07f35a488b841649cbf1b.jpg",
        description: "Soft cotton sweater in off-white. Minimalist design perfect for layering or standalone wear.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["Off-White", "Cream", "Beige", "Gray"]
    },
    {
        id: 14,
        name: "V-Neck Blouse",
        brand: "Theory",
        category: "tops",
        price: 145,
        salePrice: 101,
        discount: 30,
        rating: 4.4,
        reviews: 112,
        image: "https://kimi-web-img.moonshot.cn/img/xcdn.next.co.uk/79e180e710c7ff3950f1016bbb9d8bf24edcf68a.jpg",
        description: "Elegant V-neck blouse in silk blend. Professional yet feminine design for modern wardrobes.",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["White", "Black", "Navy", "Blush"]
    },
    {
        id: 15,
        name: "Designer Earrings",
        brand: "Kate Spade",
        category: "accessories",
        price: 78,
        salePrice: 54,
        discount: 30,
        rating: 4.6,
        reviews: 87,
        image: "https://kimi-web-img.moonshot.cn/img/www.juliensauctions.com/9ad879b12a6b4ec2d24bda8fd90eec90a13520e9.png",
        description: "Statement earrings with crystal accents. Perfect for adding sparkle to any outfit.",
        sizes: ["One Size"],
        colors: ["Gold", "Silver", "Rose Gold"]
    }
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    products = [...productData];
    filteredProducts = [...products];
    
    // Initialize components
    initializeHeroAnimation();
    initializeCountdown();
    initializeSliders();
    initializeProductGrid();
    initializeWishlist();
    initializeSearch();
    initializeScrollAnimations();
    initializeFilters();
    
    // Update UI
    updateWishlistCount();
    renderProducts();
}

// Hero section animations
function initializeHeroAnimation() {
    const heroMessages = [
        "Discover The Best Fashion Deals",
        "Curated Styles From Top Brands", 
        "Save Up To 70% On Trending Items"
    ];
    
    let currentIndex = 0;
    
    function typeNextMessage() {
        const typed = new Typed('#heroText', {
            strings: [heroMessages[currentIndex]],
            typeSpeed: 50,
            showCursor: false,
            onComplete: function() {
                setTimeout(() => {
                    typed.destroy();
                    currentIndex = (currentIndex + 1) % heroMessages.length;
                    setTimeout(typeNextMessage, 1000);
                }, 3000);
            }
        });
    }
    
    typeNextMessage();
}

// Countdown timer
function initializeCountdown() {
    const endTime = new Date().getTime() + (12 * 60 * 60 * 1000) + (34 * 60 * 1000) + (56 * 1000);
    
    function updateCountdown() {
        const now = new Date().getTime();
        const timeLeft = endTime - now;
        
        if (timeLeft > 0) {
            const hours = Math.floor(timeLeft / (1000 * 60 * 60));
            const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
            
            document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
            document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
            document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
        }
    }
    
    setInterval(updateCountdown, 1000);
    updateCountdown();
}

// Initialize product sliders
function initializeSliders() {
    const trendingSlider = new Splide('#trendingSlider', {
        type: 'loop',
        perPage: 4,
        perMove: 1,
        gap: '2rem',
        autoplay: true,
        interval: 4000,
        pauseOnHover: true,
        breakpoints: {
            1024: { perPage: 3 },
            768: { perPage: 2 },
            480: { perPage: 1 }
        }
    });
    
    trendingSlider.mount();
}

// Product grid functionality
function initializeProductGrid() {
    document.getElementById('loadMore').addEventListener('click', loadMoreProducts);
}

function renderProducts() {
    const grid = document.getElementById('productGrid');
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const productsToShow = filteredProducts.slice(0, endIndex);
    
    grid.innerHTML = '';
    
    productsToShow.forEach(product => {
        const productCard = createProductCard(product);
        grid.appendChild(productCard);
    });
    
    // Update load more button
    const loadMoreBtn = document.getElementById('loadMore');
    if (endIndex >= filteredProducts.length) {
        loadMoreBtn.style.display = 'none';
    } else {
        loadMoreBtn.style.display = 'block';
    }
    
    // Animate new products
    anime({
        targets: '.product-card',
        opacity: [0, 1],
        translateY: [30, 0],
        delay: anime.stagger(100),
        duration: 600,
        easing: 'easeOutQuart'
    });
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card rounded-2xl overflow-hidden shadow-lg cursor-pointer';
    card.onclick = () => openProductModal(product);
    
    const isInWishlist = wishlist.some(item => item.id === product.id);
    
    card.innerHTML = `
        <div class="relative">
            <img src="${product.image}" alt="${product.name}" class="w-full h-64 object-cover">
            <div class="absolute top-4 left-4 discount-badge px-3 py-1 rounded-full text-sm font-semibold">
                ${product.discount}% OFF
            </div>
            <button onclick="event.stopPropagation(); toggleWishlist(${product.id})" class="wishlist-btn absolute top-4 right-4 bg-white p-2 rounded-full shadow-lg ${isInWishlist ? 'active' : ''}">
                <svg class="w-5 h-5" fill="${isInWishlist ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                </svg>
            </button>
        </div>
        <div class="p-6">
            <div class="text-sm text-gray-500 mb-2">${product.brand.toUpperCase()}</div>
            <h3 class="font-semibold text-gray-900 mb-2">${product.name}</h3>
            <div class="flex items-center space-x-2 mb-3">
                <div class="rating-stars text-sm">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</div>
                <span class="text-gray-600 text-sm">(${product.reviews})</span>
            </div>
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <span class="price-original text-sm">$${product.price}</span>
                    <span class="price-sale font-bold">$${product.salePrice}</span>
                </div>
                <button onclick="event.stopPropagation(); openProductModal(${product.id})" class="btn-primary text-white px-4 py-2 rounded-full text-sm font-semibold">
                    Quick View
                </button>
            </div>
        </div>
    `;
    
    return card;
}

function loadMoreProducts() {
    currentPage++;
    renderProducts();
}

// Wishlist functionality
function initializeWishlist() {
    updateWishlistCount();
}

function toggleWishlist(productId) {
    const product = products.find(p => p.id === productId);
    const existingIndex = wishlist.findIndex(item => item.id === productId);
    
    if (existingIndex > -1) {
        wishlist.splice(existingIndex, 1);
        showNotification('Removed from wishlist', 'info');
    } else {
        wishlist.push(product);
        showNotification('Added to wishlist', 'success');
    }
    
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
    updateWishlistCount();
    renderProducts(); // Re-render to update heart icons
}

function updateWishlistCount() {
    document.getElementById('wishlistCount').textContent = wishlist.length;
}

// Search functionality
function initializeSearch() {
    const searchBtn = document.getElementById('searchBtn');
    const searchModal = document.getElementById('searchModal');
    const searchInput = document.getElementById('searchInput');
    
    searchBtn.addEventListener('click', openSearch);
    searchInput.addEventListener('input', handleSearch);
    
    // Close search on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeSearch();
        }
    });
}

function openSearch() {
    document.getElementById('searchModal').classList.remove('hidden');
    document.getElementById('searchInput').focus();
    document.body.style.overflow = 'hidden';
}

function closeSearch() {
    document.getElementById('searchModal').classList.add('hidden');
    document.body.style.overflow = 'auto';
}

function handleSearch(e) {
    const query = e.target.value.toLowerCase().trim();
    const resultsContainer = document.getElementById('searchResults');
    
    if (query.length < 2) {
        resultsContainer.innerHTML = '<p class="text-gray-500 text-center py-8">Start typing to search...</p>';
        return;
    }
    
    const results = products.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.brand.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
    );
    
    if (results.length === 0) {
        resultsContainer.innerHTML = '<p class="text-gray-500 text-center py-8">No products found.</p>';
        return;
    }
    
    resultsContainer.innerHTML = results.map(product => `
        <div class="flex items-center space-x-4 p-4 hover:bg-gray-50 rounded-lg cursor-pointer" onclick="closeSearch(); openProductModal(${product.id})">
            <img src="${product.image}" alt="${product.name}" class="w-16 h-16 object-cover rounded-lg">
            <div class="flex-1">
                <h4 class="font-semibold text-gray-900">${product.name}</h4>
                <p class="text-sm text-gray-500">${product.brand}</p>
                <div class="flex items-center space-x-2 mt-1">
                    <span class="text-sm text-gray-400 line-through">$${product.price}</span>
                    <span class="text-sm font-semibold text-green-600">$${product.salePrice}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Product modal functionality
function openProductModal(productId) {
    const product = typeof productId === 'object' ? productId : products.find(p => p.id === productId);
    const modal = document.getElementById('productModal');
    const content = document.getElementById('modalContent');
    
    const isInWishlist = wishlist.some(item => item.id === product.id);
    
    content.innerHTML = `
        <div class="grid md:grid-cols-2 gap-8">
            <div class="space-y-4">
                <img src="${product.image}" alt="${product.name}" class="w-full h-96 object-cover rounded-xl">
                <div class="grid grid-cols-4 gap-2">
                    ${[product.image, product.image, product.image, product.image].map(img => `
                        <img src="${img}" alt="Thumbnail" class="w-full h-20 object-cover rounded-lg cursor-pointer opacity-60 hover:opacity-100">
                    `).join('')}
                </div>
            </div>
            <div class="space-y-6">
                <div>
                    <div class="text-sm text-gray-500 mb-2">${product.brand.toUpperCase()}</div>
                    <h2 class="font-display text-3xl font-bold text-gray-900 mb-4">${product.name}</h2>
                    <p class="text-gray-600 text-lg leading-relaxed">${product.description}</p>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="rating-stars text-xl">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</div>
                    <span class="text-gray-600">(${product.reviews} reviews)</span>
                </div>
                
                <div class="flex items-center space-x-4">
                    <span class="text-3xl text-gray-400 line-through">$${product.price}</span>
                    <span class="text-4xl font-bold text-green-600">$${product.salePrice}</span>
                    <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                        Save ${product.discount}%
                    </span>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-3">Size</h4>
                    <div class="flex flex-wrap gap-2">
                        ${product.sizes.map(size => `
                            <button class="border border-gray-300 px-4 py-2 rounded-lg hover:border-rose-500 hover:text-rose-500 transition-colors">
                                ${size}
                            </button>
                        `).join('')}
                    </div>
                </div>
                
                <div>
                    <h4 class="font-semibold text-gray-900 mb-3">Color</h4>
                    <div class="flex flex-wrap gap-2">
                        ${product.colors.map(color => `
                            <button class="border border-gray-300 px-4 py-2 rounded-lg hover:border-rose-500 hover:text-rose-500 transition-colors">
                                ${color}
                            </button>
                        `).join('')}
                    </div>
                </div>
                
                <div class="flex space-x-4">
                    <button onclick="toggleWishlist(${product.id})" class="flex-1 border-2 border-gray-900 text-gray-900 px-6 py-4 rounded-full font-semibold hover:bg-gray-900 hover:text-white transition-all flex items-center justify-center">
                        <svg class="w-5 h-5 mr-2" fill="${isInWishlist ? 'currentColor' : 'none'}" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                        </svg>
                        ${isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}
                    </button>
                    <button onclick="affiliateLink(${product.id})" class="flex-1 btn-primary text-white px-6 py-4 rounded-full font-semibold flex items-center justify-center">
                        Shop Now - $${product.salePrice}
                        <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                        </svg>
                    </button>
                </div>
                
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="flex items-center justify-between text-sm text-gray-600">
                        <span>🚚 Free shipping on orders over $100</span>
                        <span>↩️ 30-day return policy</span>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeProductModal() {
    document.getElementById('productModal').classList.add('hidden');
    document.body.style.overflow = 'auto';
}

// Affiliate link handler
function affiliateLink(productId) {
    const product = products.find(p => p.id === productId);
    
    // Track affiliate click (in real implementation, this would send analytics)
    console.log('Affiliate click tracked for:', product.name);
    
    // Show loading state
    showNotification('Redirecting to retailer...', 'info');
    
    // Simulate redirect to affiliate partner
    setTimeout(() => {
        // In production, this would be a real affiliate URL
        const affiliateUrls = {
            'Lacoste': 'https://www.lacoste.com',
            'Zara': 'https://www.zara.com',
            'Adidas': 'https://www.adidas.com',
            'Reformation': 'https://www.thereformation.com',
            'Everlane': 'https://www.everlane.com',
            "Levi's": 'https://www.levi.com',
            'Coach': 'https://www.coach.com',
            'Nike': 'https://www.nike.com',
            'Gucci': 'https://www.gucci.com',
            'COS': 'https://www.cos.com',
            'Saint Laurent': 'https://www.ysl.com',
            'Theory': 'https://www.theory.com',
            'Kate Spade': 'https://www.katespade.com'
        };
        
        const url = affiliateUrls[product.brand] || 'https://www.amazon.com';
        window.open(url, '_blank');
    }, 1000);
}

// Filter functionality
function initializeFilters() {
    const filterInputs = document.querySelectorAll('input[type="checkbox"]');
    filterInputs.forEach(input => {
        input.addEventListener('change', applyFilters);
    });
}

function applyFilters() {
    const priceFilters = Array.from(document.querySelectorAll('input[type="checkbox"]:checked'))
        .filter(cb => cb.closest('.mb-6').querySelector('h4').textContent === 'Price Range')
        .map(cb => cb.nextElementSibling.textContent);
    
    const brandFilters = Array.from(document.querySelectorAll('input[type="checkbox"]:checked'))
        .filter(cb => cb.closest('.mb-6').querySelector('h4').textContent === 'Brands')
        .map(cb => cb.nextElementSibling.textContent);
    
    const categoryFilters = Array.from(document.querySelectorAll('input[type="checkbox"]:checked'))
        .filter(cb => cb.closest('.mb-6').querySelector('h4').textContent === 'Categories')
        .map(cb => cb.nextElementSibling.textContent.toLowerCase());
    
    filteredProducts = products.filter(product => {
        // Price filter
        if (priceFilters.length > 0) {
            const priceMatch = priceFilters.some(filter => {
                if (filter === 'Under $50') return product.salePrice < 50;
                if (filter === '$50 - $100') return product.salePrice >= 50 && product.salePrice <= 100;
                if (filter === '$100 - $200') return product.salePrice >= 100 && product.salePrice <= 200;
                if (filter === '$200+') return product.salePrice > 200;
                return false;
            });
            if (!priceMatch) return false;
        }
        
        // Brand filter
        if (brandFilters.length > 0 && !brandFilters.includes(product.brand)) {
            return false;
        }
        
        // Category filter
        if (categoryFilters.length > 0 && !categoryFilters.includes(product.category)) {
            return false;
        }
        
        return true;
    });
    
    currentPage = 1;
    renderProducts();
}

// Scroll animations
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    // Add fade-in class to elements and observe them
    const elementsToAnimate = document.querySelectorAll('section, .product-card, .splide__slide');
    elementsToAnimate.forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });
}

// Utility functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-24 right-6 z-50 px-6 py-4 rounded-lg shadow-lg text-white transform translate-x-full transition-transform duration-300 ${
        type === 'success' ? 'bg-green-500' : 
        type === 'error' ? 'bg-red-500' : 
        'bg-blue-500'
    }`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Navigation scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar-glass');
    if (window.scrollY > 50) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = 'none';
    }
});

// Newsletter signup
function initializeNewsletter() {
    const newsletterForm = document.querySelector('input[type="email"]').closest('div').querySelector('button');
    newsletterForm.addEventListener('click', (e) => {
        e.preventDefault();
        const email = document.querySelector('input[type="email"]').value;
        if (email && email.includes('@')) {
            showNotification('Welcome! Check your email for 15% off coupon.', 'success');
            document.querySelector('input[type="email"]').value = '';
        } else {
            showNotification('Please enter a valid email address.', 'error');
        }
    });
}

// Initialize newsletter after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializeNewsletter, 1000);
});

// Handle window resize for responsive adjustments
window.addEventListener('resize', () => {
    // Reinitialize sliders on resize
    if (window.innerWidth < 768) {
        // Mobile adjustments
    } else {
        // Desktop adjustments
    }
});

// Performance optimization - lazy load images
function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', lazyLoadImages);

// Error handling for missing images
document.addEventListener('error', (e) => {
    if (e.target.tagName === 'IMG') {
        e.target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIG5vdCBmb3VuZDwvdGV4dD48L3N2Zz4=';
    }
}, true);

console.log('StyleHub Fashion Affiliate Website Loaded Successfully! 🛍️');